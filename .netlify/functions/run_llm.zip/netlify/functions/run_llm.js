var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/run_llm.ts
var run_llm_exports = {};
__export(run_llm_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(run_llm_exports);

// src/utils/hybridEval.ts
async function evaluateOutput(output, expected, options = {}) {
  const {
    strict = false,
    allowNormalized = false,
    allowedVariants = [],
    regexVariants = [],
    useLLMCheck = false,
    llmCheckFn
  } = options;
  const normalize = (text) => text.toLowerCase().replace(/[^a-z0-9]/g, "").trim();
  const actual = output.trim();
  const expectedTrimmed = expected?.trim();
  if (!expectedTrimmed) {
    return {
      deterministicCheck: void 0,
      deterministicCheckPass: "TRUE",
      normalisedCheck: void 0,
      normalisedCheckPass: "TRUE",
      overallPassed: true,
      reason: "No expected output"
    };
  }
  const deterministicCheck = strict ? "TRUE" : void 0;
  let deterministicCheckPass = void 0;
  if (strict && actual === expectedTrimmed) {
    deterministicCheckPass = "TRUE";
  } else if (strict) {
    deterministicCheckPass = "FALSE";
  }
  const normalisedCheck = allowNormalized ? "TRUE" : void 0;
  let normalisedCheckPass = void 0;
  if (allowNormalized) {
    normalisedCheckPass = normalize(actual).includes(normalize(expectedTrimmed)) || allowedVariants.some((v) => normalize(actual).includes(normalize(v))) || regexVariants.some((rx) => rx.test(actual)) ? "TRUE" : "FALSE";
  }
  let llmCheck;
  let llmCheckPass;
  let llmReason;
  if (useLLMCheck && llmCheckFn) {
    try {
      const result = await llmCheckFn(output, expectedTrimmed);
      llmCheck = result.llmCheck;
      llmCheckPass = result.llmCheck === "TRUE" ? "TRUE" : "FALSE";
      llmReason = result.reason;
    } catch (err) {
      llmCheck = "FALSE";
      llmCheckPass = "FALSE";
      llmReason = `LLM check failed: ${err.message}`;
    }
  }
  const overallPassed = (!strict || deterministicCheckPass === "TRUE") && (!allowNormalized || normalisedCheckPass === "TRUE") && (!useLLMCheck || llmCheckPass === "TRUE");
  const reasonParts = [
    deterministicCheckPass ? `Deterministic: ${deterministicCheckPass}` : null,
    normalisedCheckPass ? `Normalised: ${normalisedCheckPass}` : null,
    llmCheckPass ? `LLM: ${llmCheckPass}${llmReason ? ` (${llmReason})` : ""}` : null
  ].filter(Boolean);
  return {
    deterministicCheck,
    deterministicCheckPass,
    normalisedCheck,
    normalisedCheckPass,
    llmCheck,
    llmCheckPass,
    llmReason,
    overallPassed,
    reason: reasonParts.join("; ") || "Failed all checks"
  };
}

// netlify/functions/run_llm.ts
var MODEL_PRICING = {
  "HuggingFaceH4/zephyr-7b-beta": { input: 2e-4, output: 2e-4 },
  "mistralai/Mistral-7B-Instruct-v0.2": { input: 2e-4, output: 2e-4 },
  "meta-llama/Llama-3.1-8B-Instruct": { input: 2e-4, output: 2e-4 }
};
var DEFAULT_PRICING = { input: 2e-4, output: 2e-4 };
function estimateCost(modelName, promptTokens, completionTokens) {
  const pricing = MODEL_PRICING[modelName] ?? DEFAULT_PRICING;
  return promptTokens / 1e3 * pricing.input + completionTokens / 1e3 * pricing.output;
}
async function callHFRouter(model, systemPrompt, userPrompt, temperature, maxTokens, token) {
  const modelId = model.includes(":") ? model : `${model}:featherless-ai`;
  const res = await fetch("https://router.huggingface.co/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: modelId,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      temperature,
      max_tokens: maxTokens
    })
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`HF Router Error ${res.status}: ${text}`);
  }
  const data = await res.json();
  return {
    content: data.choices?.[0]?.message?.content ?? "",
    usage: {
      promptTokens: data.usage?.prompt_tokens ?? 0,
      completionTokens: data.usage?.completion_tokens ?? 0,
      totalTokens: data.usage?.total_tokens ?? 0
    }
  };
}
function makeSemanticCheckFn(model, hfToken) {
  return async (output, expected) => {
    const prompt = `You are an evaluation judge. Your task is to assess whether an LLM output meets the expected criteria.

Expected criteria:
${expected}

LLM output to evaluate:
${output}

Respond with a JSON object only, no other text, no markdown, no explanation outside the JSON:
{"pass": true, "reason": "brief explanation of why the output meets the criteria"}
or
{"pass": false, "reason": "brief explanation of why the output does not meet the criteria"}`;
    const raw = await callHFRouter(
      model,
      "You are a strict evaluation judge. You respond only with a valid JSON object containing 'pass' (boolean) and 'reason' (string). No markdown, no preamble, no explanation outside the JSON.",
      prompt,
      0,
      150,
      hfToken
    );
    const cleaned = raw.content.replace(/```json\s*/i, "").replace(/```/g, "").trim();
    try {
      const parsed = JSON.parse(cleaned);
      const pass = parsed.pass === true || parsed.pass === "true";
      const reason = typeof parsed.reason === "string" && parsed.reason.trim() ? parsed.reason.trim() : "No explanation provided";
      return { llmCheck: pass ? "TRUE" : "FALSE", reason };
    } catch {
      const fallbackPass = cleaned.toLowerCase().includes('"pass": true') || cleaned.toLowerCase().includes('"pass":true');
      return {
        llmCheck: fallbackPass ? "TRUE" : "FALSE",
        reason: `JSON parse failed. Raw response: ${cleaned.slice(0, 200)}`
      };
    }
  };
}
var handler = async (event) => {
  const start = Date.now();
  let retried = false;
  let usage = {
    promptTokens: 0,
    completionTokens: 0,
    totalTokens: 0
  };
  try {
    const hfToken = process.env.HF_TOKEN;
    if (!hfToken) throw new Error("Missing HF_TOKEN environment variable");
    const body = JSON.parse(event.body || "{}");
    const { promptConfig, testCase, runNumber } = body;
    const userPrompt = promptConfig.userTemplate.replace("{{input}}", testCase.input);
    let output = "";
    try {
      const hfResponse = await callHFRouter(
        promptConfig.modelName,
        promptConfig.systemPrompt,
        userPrompt,
        Math.min(promptConfig.temperature, 1),
        Math.min(promptConfig.maxTokens, 1024),
        hfToken
      );
      output = hfResponse.content;
      usage = hfResponse.usage;
    } catch (err) {
      const errMsg = err.message;
      if (promptConfig.retryOnInvalid && errMsg.includes("HF Router Error")) {
        retried = true;
        try {
          const retryResponse = await callHFRouter(
            promptConfig.modelName,
            promptConfig.systemPrompt,
            userPrompt,
            Math.min(promptConfig.temperature, 1),
            Math.min(promptConfig.maxTokens, 1024),
            hfToken
          );
          output = retryResponse.content;
          usage = retryResponse.usage;
        } catch (err2) {
          output = `Error after retry: ${err2.message}`;
          retried = false;
        }
      } else {
        output = `Error: ${errMsg}`;
      }
    }
    let validJson = false;
    try {
      JSON.parse(output);
      validJson = true;
    } catch {
      validJson = false;
    }
    const evalOptions = {
      strict: testCase.strict ?? false,
      allowNormalized: testCase.allowNormalized ?? true,
      useLLMCheck: testCase.useLLMCheck ?? false,
      llmCheckFn: testCase.useLLMCheck ? makeSemanticCheckFn(promptConfig.modelName, hfToken) : void 0
    };
    const evalResult = await evaluateOutput(output, testCase.expectedOutput, evalOptions);
    const estimatedCostUsd = estimateCost(
      promptConfig.modelName,
      usage.promptTokens,
      usage.completionTokens
    );
    const result = {
      testCaseId: testCase.id,
      input: testCase.input,
      output,
      passed: evalResult.overallPassed,
      reason: evalResult.reason,
      validJson,
      retried,
      latency: Date.now() - start,
      runNumber,
      deterministicCheck: evalResult.deterministicCheck,
      deterministicCheckPass: evalResult.deterministicCheckPass,
      normalisedCheck: evalResult.normalisedCheck,
      normalisedCheckPass: evalResult.normalisedCheckPass,
      llmCheck: evalResult.llmCheck,
      llmCheckPass: evalResult.llmCheckPass,
      llmReason: evalResult.llmReason,
      promptTokens: usage.promptTokens,
      completionTokens: usage.completionTokens,
      totalTokens: usage.totalTokens,
      estimatedCostUsd
    };
    return { statusCode: 200, body: JSON.stringify(result) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
